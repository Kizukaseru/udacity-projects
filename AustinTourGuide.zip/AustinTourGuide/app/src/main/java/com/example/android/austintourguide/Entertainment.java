package com.example.android.austintourguide;

import android.content.Context;
import java.util.List;

public class Entertainment {
    public static void initEntertainmentList(List<Item> list, Context context) {

        list.add(new Item(
                context.getString(R.string.topten_limits_name),
                context.getString(R.string.topten_limits_address),
                context.getString(R.string.topten_limits_description),
                context.getString(R.string.topten_limits_website),
                R.drawable.limits_image
        ));

        list.add(new Item(
                context.getString(R.string.topten_zach_name),
                context.getString(R.string.topten_zach_address),
                context.getString(R.string.topten_zach_description),
                context.getString(R.string.topten_zach_website),
                R.drawable.zach_image
        ));

        list.add(new Item(
                context.getString(R.string.topten_drafthouse_name),
                context.getString(R.string.topten_drafthouse_address),
                context.getString(R.string.topten_drafthouse_description),
                context.getString(R.string.topten_drafthouse_website),
                R.drawable.drafthouse_image
        ));

        list.add(new Item(
                context.getString(R.string.topten_pinballz_name),
                context.getString(R.string.topten_pinballz_address),
                context.getString(R.string.topten_pinballz_description),
                context.getString(R.string.topten_pinballz_website),
                R.drawable.pinballz_image
        ));

        list.add(new Item(
                context.getString(R.string.topten_escape_name),
                context.getString(R.string.topten_escape_address),
                context.getString(R.string.topten_escape_description),
                context.getString(R.string.topten_escape_website),
                R.drawable.escape_image
        ));

        list.add(new Item(
                context.getString(R.string.entertainment_axes_name),
                context.getString(R.string.entertainment_axes_address),
                context.getString(R.string.entertainment_axes_description),
                context.getString(R.string.entertainment_axes_website),
                R.drawable.axes_image
        ));
    }
}
