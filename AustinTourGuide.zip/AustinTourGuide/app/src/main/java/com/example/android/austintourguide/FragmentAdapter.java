package com.example.android.austintourguide;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

public class FragmentAdapter extends FragmentPagerAdapter {

    private Context context;

    public FragmentAdapter(Context context, FragmentManager fm) {
        super(fm);
        this.context = context;
    }

    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
                return new TopTenFragment();
            case 1:
                return new NightlifeFragment();
            case 2:
                return new ShoppingFragment();
            case 3:
                return new OutdoorsFragment();
            default:
                return new EntertainmentFragment();
        }
    }

    @Override
    public int getCount() {
        return 5;
    }

    @Override
    public CharSequence getPageTitle(int position) {
        switch (position) {
            case 0:
                return context.getString(R.string.title_top);
            case 1:
                return context.getString(R.string.title_nightlife);
            case 2:
                return context.getString(R.string.title_shopping);
            case 3:
                return context.getString(R.string.title_outdoors);
            default:
                return context.getString(R.string.title_fun);
        }
    }
}