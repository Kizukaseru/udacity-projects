package com.example.android.austintourguide;

import android.util.Log;

public class Item {
    private String name;
    private String description;
    private String address;
    private String website;
    private static final int NO_IMAGE_PROVIDED = -1;
    private int imageResourceId;

    public Item(String name, String description, String address, String website, int imageResourceId) {
        this.name = name;
        this.description = description;
        this.website = website;
        this.address = address;
        this.imageResourceId = imageResourceId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public String getAddress() {
        return address;
    }

    public String getWebsite() {
        return website;
    }

    public int getImageResourceId() {
        return imageResourceId;
    }

    public boolean hasImage(){
        Log.v("hasImage", "word has image: "+ (imageResourceId != NO_IMAGE_PROVIDED));
        return imageResourceId != NO_IMAGE_PROVIDED;
    }
    public boolean hasWebsite(){
        return getWebsite() != null;
    }

    public boolean hasAddress(){
        return getAddress() != null;
    }


    @Override
    public String toString() {
        String output = getName() + "\n" +
                getDescription() + "\n" +
                getAddress() + "\n" +
                getWebsite() + "\n" +
                getImageResourceId()
                ;

        return output;
    }
}

