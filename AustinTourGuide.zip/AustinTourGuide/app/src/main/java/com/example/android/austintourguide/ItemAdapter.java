package com.example.android.austintourguide;

import android.content.Context;
import android.location.Location;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class ItemAdapter extends ArrayAdapter<Item> {

    public ItemAdapter(Context context, int resources, List<Item> itemList) {
        super(context, 0, itemList);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        final Item currentItem = getItem(position);
        View listItemView = convertView;

        if(listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.place_item, parent, false);
        }

        TextView nameItemTextView = (TextView) listItemView.findViewById(R.id.nameTextView);
        nameItemTextView.setText(currentItem.getName());

        TextView descriptionTextView = (TextView)
                listItemView.findViewById(R.id.descriptionTextView);
        descriptionTextView.setText(currentItem.getDescription());

        TextView websiteTextView = (TextView) listItemView.findViewById(R.id.websiteTextView);
        websiteTextView.setText(currentItem.getWebsite());

        TextView addressTextView = (TextView) listItemView.findViewById(R.id.addressTextView);
        addressTextView.setText(currentItem.getAddress());

        ImageView photoImageView = (ImageView) listItemView.findViewById(R.id.photoImageView);

        if (currentItem.hasImage()){
            photoImageView.setImageResource(currentItem.getImageResourceId());
            photoImageView.setVisibility(View.VISIBLE);
        } else {
            photoImageView.setVisibility(View.GONE);
        }


        if (currentItem.hasAddress()){
            addressTextView.setVisibility(View.VISIBLE);
        } else {
            addressTextView.setVisibility(View.GONE);
        }

        if (currentItem.hasWebsite()){
            websiteTextView.setVisibility(View.VISIBLE);
        } else {
            websiteTextView.setVisibility(View.GONE);
        }


        return listItemView;
    }


}
