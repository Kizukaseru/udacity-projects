package com.example.android.austintourguide;

import android.content.Context;

import java.util.List;

public class Nightlife {
    public static void initNightlifeList(List<Item> list, Context context) {

        list.add(new Item(
                context.getString(R.string.topten_drafthouse_name),
                context.getString(R.string.topten_drafthouse_address),
                context.getString(R.string.topten_drafthouse_description),
                context.getString(R.string.topten_drafthouse_website),
                R.drawable.drafthouse_image
        ));

        list.add(new Item(
                context.getString(R.string.nightlife_vigilante_name),
                context.getString(R.string.nightlife_vigilante_address),
                context.getString(R.string.nightlife_vigilante_description),
                context.getString(R.string.nightlife_vigilante_website),
                R.drawable.vigilante_image
        ));

        list.add(new Item(
                context.getString(R.string.nightlife_brass_name),
                context.getString(R.string.nightlife_brass_address),
                context.getString(R.string.nightlife_brass_description),
                context.getString(R.string.nightlife_brass_website),
                R.drawable.brass_image
        ));

        list.add(new Item(
                context.getString(R.string.nightlife_maggie_name),
                context.getString(R.string.nightlife_maggie_address),
                context.getString(R.string.nightlife_maggie_description),
                context.getString(R.string.nightlife_maggie_website),
                R.drawable.maggie_image
        ));
    }
}
