package com.example.android.austintourguide;

import android.content.Context;

import java.util.List;

public class Outdoors {
    public static void initOutdoorsList(List<Item> list, Context context) {
        list.add(new Item(
                context.getString(R.string.topten_greenbelt_name),
                context.getString(R.string.topten_greenbelt_address),
                context.getString(R.string.topten_greenbelt_description),
                context.getString(R.string.topten_greenbelt_website),
                R.drawable.greenbelt_image
        ));

        list.add(new Item(
                context.getString(R.string.topten_bonnell_name),
                context.getString(R.string.topten_bonnell_address),
                context.getString(R.string.topten_bonnell_description),
                context.getString(R.string.topten_bonnell_website),
                R.drawable.bonnell_image
        ));

        list.add(new Item(
                context.getString(R.string.topten_pool_name),
                context.getString(R.string.topten_pool_address),
                context.getString(R.string.topten_pool_description),
                context.getString(R.string.topten_pool_website),
                R.drawable.pool_image
        ));

        list.add(new Item(
                context.getString(R.string.outdoor_bats_name),
                context.getString(R.string.outdoor_bats_address),
                context.getString(R.string.outdoor_bats_description),
                context.getString(R.string.outdoor_bats_website),
                R.drawable.bats_image
        ));
    }
}

