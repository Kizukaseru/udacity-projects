package com.example.android.austintourguide;

import android.content.Context;

import java.util.List;

public class Shopping {
    public static void initShoppingList(List<Item> list, Context context) {

        list.add(new Item(
                context.getString(R.string.topten_domain_name),
                context.getString(R.string.topten_domain_address),
                context.getString(R.string.topten_domain_description),
                context.getString(R.string.topten_domain_website),
                R.drawable.domain_image
        ));

        list.add(new Item(
                context.getString(R.string.shopping_lair_name),
                context.getString(R.string.shopping_lair_address),
                context.getString(R.string.shopping_lair_description),
                context.getString(R.string.shopping_lair_website),
                R.drawable.lair_image
        ));

        list.add(new Item(
                context.getString(R.string.shopping_hmart_name),
                context.getString(R.string.shopping_hmart_address),
                context.getString(R.string.shopping_hmart_description),
                context.getString(R.string.shopping_hmart_website),
                R.drawable.hmart_image
        ));

        list.add(new Item(
                context.getString(R.string.shopping_arboretum_name),
                context.getString(R.string.shopping_arboretum_address),
                context.getString(R.string.shopping_arboretum_description),
                context.getString(R.string.shopping_arboretum_website),
                R.drawable.arboretum_image
        ));
    }
}

