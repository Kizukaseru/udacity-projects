package com.example.android.austintourguide;

import android.content.Context;

import java.util.List;

public class TopTen {
    public static void initTopTenList(List<Item> list, Context context) {

        list.add(new Item(
                context.getString(R.string.topten_zach_name),
                context.getString(R.string.topten_zach_address),
                context.getString(R.string.topten_zach_description),
                context.getString(R.string.topten_zach_website),
                R.drawable.zach_image
        ));

        list.add(new Item(
                context.getString(R.string.topten_drafthouse_name),
                context.getString(R.string.topten_drafthouse_address),
                context.getString(R.string.topten_drafthouse_description),
                context.getString(R.string.topten_drafthouse_website),
                R.drawable.drafthouse_image
        ));

        list.add(new Item(
                context.getString(R.string.topten_limits_name),
                context.getString(R.string.topten_limits_address),
                context.getString(R.string.topten_limits_description),
                context.getString(R.string.topten_limits_website),
                R.drawable.limits_image
        ));

        list.add(new Item(
                context.getString(R.string.topten_pinballz_name),
                context.getString(R.string.topten_pinballz_address),
                context.getString(R.string.topten_pinballz_description),
                context.getString(R.string.topten_pinballz_website),
                R.drawable.pinballz_image
        ));

        list.add(new Item(
                context.getString(R.string.topten_capitol_name),
                context.getString(R.string.topten_capitol_address),
                context.getString(R.string.topten_capitol_description),
                context.getString(R.string.topten_capitol_website),
                R.drawable.capitol_image
        ));

        list.add(new Item(
                context.getString(R.string.topten_greenbelt_name),
                context.getString(R.string.topten_greenbelt_address),
                context.getString(R.string.topten_greenbelt_description),
                context.getString(R.string.topten_greenbelt_website),
                R.drawable.greenbelt_image
        ));

        list.add(new Item(
                context.getString(R.string.topten_bonnell_name),
                context.getString(R.string.topten_bonnell_address),
                context.getString(R.string.topten_bonnell_description),
                context.getString(R.string.topten_bonnell_website),
                R.drawable.bonnell_image
        ));

        list.add(new Item(
                context.getString(R.string.topten_domain_name),
                context.getString(R.string.topten_domain_address),
                context.getString(R.string.topten_domain_description),
                context.getString(R.string.topten_domain_website),
                R.drawable.domain_image
        ));

        list.add(new Item(
                context.getString(R.string.topten_pool_name),
                context.getString(R.string.topten_pool_address),
                context.getString(R.string.topten_pool_description),
                context.getString(R.string.topten_pool_website),
                R.drawable.pool_image
        ));

        list.add(new Item(
                context.getString(R.string.topten_escape_name),
                context.getString(R.string.topten_escape_address),
                context.getString(R.string.topten_escape_description),
                context.getString(R.string.topten_escape_website),
                R.drawable.escape_image
        ));
    }
}


