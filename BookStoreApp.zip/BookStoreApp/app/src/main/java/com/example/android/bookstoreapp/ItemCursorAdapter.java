package com.example.android.bookstoreapp;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import static com.example.android.bookstoreapp.R.drawable.ic_book_black_24dp;
import static com.example.android.bookstoreapp.data.ItemContract.BookEntry;


class ItemCursorAdapter extends CursorAdapter {

    private static final String TAG = ItemCursorAdapter.class.getSimpleName();


    ItemCursorAdapter(Context context, Cursor c) {
        super(context, c, 0);
    }

    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        return LayoutInflater.from(context).inflate(R.layout.inventory_item, parent, false);

    }

    @Override
    public void bindView(View view, final Context context, Cursor cursor) {
        final int id = cursor.getInt(cursor.getColumnIndexOrThrow(BookEntry._ID));
        TextView product_name = view.findViewById(R.id.inventory_item_name_text);
        TextView product_quantity = view.findViewById(R.id.inventory_item_current_quantity_text);
        TextView product_price = view.findViewById(R.id.inventory_item_price_text);
        TextView product_sold = view.findViewById(R.id.inventory_item_current_sold_text);
        ImageView product_sell_btn = view.findViewById(R.id.sell_product);
        ImageView product_add_btn = view.findViewById(R.id.add_product);
        ImageView product_sub_btn = view.findViewById(R.id.sub_product);
        ImageView product_refund_btn = view.findViewById(R.id.refund_product);
        ImageView product_thumbnail = view.findViewById(R.id.product_thumbnail);


        int nameColumnIndex = cursor.getColumnIndex(BookEntry.COL_NAME);
        int quantityColumnIndex = cursor.getColumnIndex(BookEntry.COL_QUANTITY);
        int priceColumnIndex = cursor.getColumnIndex(BookEntry.COL_PRICE);
        int thumbnailColumnIndex = cursor.getColumnIndex(BookEntry.COL_PICTURE);
        int salesColumnIndex = cursor.getColumnIndex(BookEntry.COL_ITEMS_SOLD);

        final String productName = cursor.getString(nameColumnIndex);
        final int quantity = cursor.getInt(quantityColumnIndex);
        final int products_sold = cursor.getInt(salesColumnIndex);
        String productPrice = "Price: $" + cursor.getString(priceColumnIndex);
        Uri thumbUri = Uri.parse(cursor.getString(thumbnailColumnIndex));

        String productQuantity = "Inventory: " + String.valueOf(quantity);
        String productSold = "Sold: " + String.valueOf(products_sold);

        final Uri currentProductUri = ContentUris.withAppendedId(BookEntry.CONTENT_URI, id);

        Log.d(TAG, "current Uri: " + currentProductUri + " Product name: " + productName + " id: " + id);

        product_name.setText(productName);
        product_quantity.setText(productQuantity);
        product_price.setText(productPrice);
        product_sold.setText(productSold);
        //We use Glide to import photo images
        Glide.with(context).load(thumbUri)
                .placeholder(R.drawable.ic_book_black_24dp)
                .error(ic_book_black_24dp)
                .crossFade()
                .centerCrop()
                .into(product_thumbnail);


        product_sell_btn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Log.d(TAG, productName + " quantity= " + quantity);
                ContentResolver resolver = view.getContext().getContentResolver();
                ContentValues values = new ContentValues();
                if (quantity > 0) {
                    int qq = quantity;
                    int yy = products_sold;
                    Log.d(TAG, "new quantity= " + qq);
                    values.put(BookEntry.COL_QUANTITY, --qq);
                    values.put(BookEntry.COL_ITEMS_SOLD, ++yy);
                    resolver.update(
                            currentProductUri,
                            values,
                            null,
                            null
                    );
                    context.getContentResolver().notifyChange(currentProductUri, null);
                } else {
                    Toast.makeText(context, "Book unavailable", Toast.LENGTH_SHORT).show();
                }
            }
        });
        product_refund_btn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Log.d(TAG, productName + " quantity= " + quantity);
                ContentResolver resolver = view.getContext().getContentResolver();
                ContentValues values = new ContentValues();
                if (products_sold > 0) {
                    int qq = quantity;
                    int yy = products_sold;
                    Log.d(TAG, "new sale= " + qq);
                    values.put(BookEntry.COL_QUANTITY, ++qq);
                    values.put(BookEntry.COL_ITEMS_SOLD, --yy);
                    resolver.update(
                            currentProductUri,
                            values,
                            null,
                            null
                    );
                    context.getContentResolver().notifyChange(currentProductUri, null);
                } else {
                    Toast.makeText(context, "No books sold", Toast.LENGTH_SHORT).show();
                }
            }
        });

        product_add_btn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Log.d(TAG, productName + " quantity= " + quantity);
                ContentResolver resolver = view.getContext().getContentResolver();
                ContentValues values = new ContentValues();
                if (products_sold > -1 && quantity > -1) {
                    int qq = quantity;
                    Log.d(TAG, "new quantity= " + qq);
                    values.put(BookEntry.COL_QUANTITY, ++qq);
                    resolver.update(
                            currentProductUri,
                            values,
                            null,
                            null
                    );
                    context.getContentResolver().notifyChange(currentProductUri, null);
                } else {
                    Toast.makeText(context, "Something went wrong", Toast.LENGTH_SHORT).show();
                }
            }
        });
        product_sub_btn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Log.d(TAG, productName + " quantity= " + quantity);
                ContentResolver resolver = view.getContext().getContentResolver();
                ContentValues values = new ContentValues();
                if (quantity > 0) {
                    int qq = quantity;
                    Log.d(TAG, "new quantity= " + qq);
                    values.put(BookEntry.COL_QUANTITY, --qq);
                    resolver.update(
                            currentProductUri,
                            values,
                            null,
                            null
                    );
                    context.getContentResolver().notifyChange(currentProductUri, null);
                } else {
                    Toast.makeText(context, "Cannot have a negative amount of books in stock", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}
