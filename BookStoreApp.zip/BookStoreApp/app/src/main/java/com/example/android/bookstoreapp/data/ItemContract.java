package com.example.android.bookstoreapp.data;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.net.Uri;
import android.provider.BaseColumns;

/**
 * API Contract for Bookstore app
 */

public class ItemContract {


    public static final String CONTENT_AUTHORITY = "com.example.android.bookstoreapp";
    /**
     * Use CONTENT_AUTHORITY to create the base of all URI's which apps will use to contact
     * the content provider.
     */
    private static final Uri BASE_CONTENT_URI = Uri.parse("content://" + CONTENT_AUTHORITY);
    public static final String PATH_INVENTORY = "bookstore";

    // To prevent someone from accidentally instantiating the contract class,
    // give it an empty constructor.
    public ItemContract() {
    }

    /**
     * Inner class that defines constant values for the bookstore database table.
     * Each entry in the table represents a single inventory item.
     */

    public static final class BookEntry implements BaseColumns {

        /**
         * The content URI to access the inventory data in the provider
         */
        public static final Uri CONTENT_URI = Uri.withAppendedPath(BASE_CONTENT_URI, PATH_INVENTORY);

        /**
         * The MIME type of the {@link #CONTENT_URI} for a list of products.
         */
        public static final String CONTENT_LIST_TYPE =
                ContentResolver.CURSOR_DIR_BASE_TYPE + "/" + CONTENT_AUTHORITY + "/" + PATH_INVENTORY;

        /**
         * The MIME type of the {@link #CONTENT_URI} for a single product.
         */
        public static final String CONTENT_ITEM_TYPE =
                ContentResolver.CURSOR_ITEM_BASE_TYPE + "/" + CONTENT_AUTHORITY + "/" + PATH_INVENTORY;

        /**
         * Name of database table for inventory
         */
        public final static String TABLE_NAME = "bookstore";

        public final static String _ID = BaseColumns._ID;
        public final static String COL_NAME = "name";
        public final static String COL_QUANTITY = "quantity";
        public final static String COL_PRICE = "price";
        public final static String COL_DESCRIPTION = "description";
        public final static String COL_ITEMS_SOLD = "sales";
        public final static String COL_PUBLISHER = "publisher";
        public final static String COL_PUBLISHER_EMAIL = "publisher_email";
        public final static String COL_PUBLISHER_PHONE = "publisher_phone";
        public final static String COL_PICTURE = "picture";

        public static Uri buildBookURI(long id) {
            return ContentUris.withAppendedId(CONTENT_URI, id);
        }

    }

}
