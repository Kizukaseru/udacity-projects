package com.example.android.bookstoreapp.data;


import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.android.bookstoreapp.data.ItemContract.BookEntry;

class ItemDbHelper extends SQLiteOpenHelper {

    public static final String TAG = ItemDbHelper.class.getSimpleName();

    /**
     * Name of the database file
     */
    private static final String DATABASE_NAME = "bookstore.db";

    /**
     * Database version. If you change the database schema, you must increment the database version.
     */
    private static final int DATABASE_VERSION = 1;


    public ItemDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String SQL_CREATE_INVENTORY = "CREATE TABLE " + BookEntry.TABLE_NAME + " ("
                + BookEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + BookEntry.COL_NAME + " TEXT NOT NULL, "
                + BookEntry.COL_QUANTITY + " INTEGER NOT NULL DEFAULT 0, "
                + BookEntry.COL_PRICE + " REAL NOT NULL DEFAULT 0.0, "
                + BookEntry.COL_PICTURE + " TEXT NOT NULL DEFAULT 'No images', "
                + BookEntry.COL_DESCRIPTION + " TEXT NOT NULL DEFAULT 'New Book Description', "
                + BookEntry.COL_ITEMS_SOLD + " INTEGER NOT NULL DEFAULT 0, "
                + BookEntry.COL_PUBLISHER + " TEXT NOT NULL DEFAULT 'Random Publisher', "
                + BookEntry.COL_PUBLISHER_EMAIL + " TEXT NOT NULL DEFAULT 'publisher@gmail.com',"
                + BookEntry.COL_PUBLISHER_PHONE + " TEXT NOT NULL DEFAULT '999-999-9999'"
                + ");";

        db.execSQL(SQL_CREATE_INVENTORY);
    }


    //Todo change the drop table implementation to more user friendly version that doesn't delete user data
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + BookEntry.TABLE_NAME);
        onCreate(sqLiteDatabase);

    }
}
