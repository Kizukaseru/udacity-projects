package com.example.android.judoscoring;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.concurrent.TimeUnit;

/**
 * This activity keeps track of the score for 2 judoka. The first Judoka to reach a score of 100 wins.
 * Ippon is an instant victory; Waza-Ari is worth 50 points; Yuko is worth 10 points.
 * Timer code adapted from http://www.androidtutorialshub.com/android-count-down-timer-tutorial/
 */
public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    // Tracks the score for Team A
    @SuppressWarnings("WeakerAccess")
    int WhiteJudoka = 0;
    // Tracks the score for Team B
    @SuppressWarnings("WeakerAccess")
    int BlueJudoka = 0;
    private long timeCountInMilliSeconds = 1 * 60000;
    private TimerStatus timerStatus = TimerStatus.STOPPED;
    private ProgressBar progressBarCircle;
    private EditText editTextMinute;
    private TextView textViewTime;
    private ImageView imageViewReset;
    private ImageView imageViewStartStop;
    private CountDownTimer countDownTimer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // method call to initialize the views
        initViews();
        // method call to initialize the listeners
        initListeners();

    }

    /**
     * Increase the score for White Judoka by 1 point.
     */
    @SuppressWarnings("unused")
    public void addOneForWhite(View v) {
        WhiteJudoka = WhiteJudoka + 10;
        displayForWhite(WhiteJudoka);
    }

    /**
     * Increase the score for White Judoka by 2 points.
     */
    @SuppressWarnings("unused")
    public void addTwoForWhite(View v) {
        WhiteJudoka = WhiteJudoka + 50;
        displayForWhite(WhiteJudoka);
    }

    /**
     * Increase the score for White Judoka by 3 points.
     */
    @SuppressWarnings("unused")
    public void addThreeForWhite(View v) {
        WhiteJudoka = WhiteJudoka + 100;
        displayForWhite(WhiteJudoka);
    }

    /**
     * Increase the score for Blue Judoka by 1 point.
     */
    @SuppressWarnings("unused")
    public void addOneForBlue(View v) {
        BlueJudoka = BlueJudoka + 10;
        displayForBlue(BlueJudoka);
    }

    /**
     * Increase the score for Blue Judoka by 2 points.
     */
    @SuppressWarnings("unused")
    public void addTwoForBlue(View v) {
        BlueJudoka = BlueJudoka + 50;
        displayForBlue(BlueJudoka);
    }

    /**
     * Increase the score for Blue Judoka by 3 points.
     */
    @SuppressWarnings("unused")
    public void addThreeForBlue(View v) {
        BlueJudoka = BlueJudoka + 100;
        displayForBlue(BlueJudoka);
    }

    /**
     * Resets the score for both Judoka back to 0.
     */
    @SuppressWarnings("unused")
    public void resetScore(View v) {
        WhiteJudoka = 0;
        BlueJudoka = 0;
        displayForWhite(WhiteJudoka);
        displayForBlue(BlueJudoka);
    }

    /**
     * Displays the given score for White Judoka.
     */
    @SuppressWarnings("WeakerAccess")
    public void displayForWhite(int score) {
        TextView scoreView = findViewById(R.id.white_score);
        scoreView.setText(String.valueOf(score));
    }

    /**
     * Displays the given score for Blue Judoka.
     */
    @SuppressWarnings("WeakerAccess")
    public void displayForBlue(int score) {
        TextView scoreView = findViewById(R.id.blue_score);
        scoreView.setText(String.valueOf(score));
    }

    /**
     * method to initialize the views
     */
    private void initViews() {
        progressBarCircle = (ProgressBar) findViewById(R.id.progressBarCircle);
        editTextMinute = (EditText) findViewById(R.id.editTextMinute);
        textViewTime = (TextView) findViewById(R.id.textViewTime);
        imageViewReset = (ImageView) findViewById(R.id.imageViewReset);
        imageViewStartStop = (ImageView) findViewById(R.id.imageViewStartStop);
    }

    /**
     * method to initialize the click listeners
     */
    private void initListeners() {
        imageViewReset.setOnClickListener(this);
        imageViewStartStop.setOnClickListener(this);
    }

    /**
     * implemented method to listen clicks
     */
    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.imageViewReset:
                reset();
                break;
            case R.id.imageViewStartStop:
                startStop();
                break;
        }
    }

    /**
     * method to reset count down timer
     */
    private void reset() {
        stopCountDownTimer();
        startCountDownTimer();

    }

    /**
     * method to start and stop count down timer and reset scores for Judoka
     */
    private void startStop() {
        if (timerStatus == TimerStatus.STOPPED) {

            // call to initialize the timer values
            setTimerValues();
            // call to initialize the progress bar values
            setProgressBarValues();
            // showing the reset icon
            imageViewReset.setVisibility(View.VISIBLE);
            // changing play icon to stop icon
            imageViewStartStop.setImageResource(R.drawable.icon_stop);
            // making edit text not editable
            editTextMinute.setEnabled(false);
            // changing the timer status to started
            timerStatus = TimerStatus.STARTED;
            // call to start the count down timer
            startCountDownTimer();

        } else {

            // hiding the reset icon
            imageViewReset.setVisibility(View.GONE);
            // changing stop icon to start icon
            imageViewStartStop.setImageResource(R.drawable.icon_start);
            // making edit text editable
            editTextMinute.setEnabled(true);
            // changing the timer status to stopped
            timerStatus = TimerStatus.STOPPED;
            stopCountDownTimer();
            //Initializing Player Scores
            WhiteJudoka = 0;
            BlueJudoka = 0;
            displayForWhite(WhiteJudoka);
            displayForBlue(BlueJudoka);

        }

    }

    /**
     * method to initialize the values for count down timer
     */
    private void setTimerValues() {
        int time = 0;
        if (!editTextMinute.getText().toString().isEmpty()) {
            // fetching value from edit text and type cast to integer
            time = Integer.parseInt(editTextMinute.getText().toString().trim());
        } else {
            // toast message to fill edit text
            Toast.makeText(getApplicationContext(), getString(R.string.message_minutes), Toast.LENGTH_LONG).show();
        }
        // assigning values after converting to milliseconds
        timeCountInMilliSeconds = time * 60 * 1000;
    }

    /**
     * method to start count down timer
     */
    private void startCountDownTimer() {

        countDownTimer = new CountDownTimer(timeCountInMilliSeconds, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {

                textViewTime.setText(hmsTimeFormatter(millisUntilFinished));

                progressBarCircle.setProgress((int) (millisUntilFinished / 1000));

            }

            @Override
            public void onFinish() {

                textViewTime.setText(hmsTimeFormatter(timeCountInMilliSeconds));
                // call to initialize the progress bar values
                setProgressBarValues();
                // hiding the reset icon
                imageViewReset.setVisibility(View.GONE);
                // changing stop icon to start icon
                imageViewStartStop.setImageResource(R.drawable.icon_start);
                // making edit text editable
                editTextMinute.setEnabled(true);
                // changing the timer status to stopped
                timerStatus = TimerStatus.STOPPED;
            }

        }.start();
        countDownTimer.start();
    }

    /**
     * method to stop count down timer
     */
    private void stopCountDownTimer() {
        countDownTimer.cancel();
    }

    /**
     * method to set circular progress bar values
     */
    private void setProgressBarValues() {

        progressBarCircle.setMax((int) timeCountInMilliSeconds / 1000);
        progressBarCircle.setProgress((int) timeCountInMilliSeconds / 1000);
    }

    /**
     * method to convert millisecond to time format
     *
     * @return HH:mm:ss time formatted string
     */
    private String hmsTimeFormatter(long milliSeconds) {

        return String.format("%02d:%02d:%02d",
                TimeUnit.MILLISECONDS.toHours(milliSeconds),
                TimeUnit.MILLISECONDS.toMinutes(milliSeconds) - TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(milliSeconds)),
                TimeUnit.MILLISECONDS.toSeconds(milliSeconds) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(milliSeconds)));


    }


    private enum TimerStatus {
        STARTED,
        STOPPED
    }

}