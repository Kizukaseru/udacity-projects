package com.android.musicplayer;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

import java.util.ArrayList;

public class AlbumsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.item_list);


        // Create a list of words
        ArrayList<Song> songs = new ArrayList<>();
        songs.add(new Song("Track One", "Artist One","Album One"));
        songs.add(new Song("Track Two", "Artist One","Album Two"));
        songs.add(new Song("Track Three", "Artist Two","Album One"));
        songs.add(new Song("Track Four", "Artist Two","Album Two"));
        songs.add(new Song("Track Five", "Artist Three","Album One"));
        songs.add(new Song("Track Six", "Artist Three","Album Two"));
        songs.add(new Song("Track Seven", "Artist Four","Album One"));
        songs.add(new Song("Track Eight", "Artist Four","Album Two"));

        // Create an {@link WordAdapter}, whose data source is a list of {@link Word}s. The
        // adapter knows how to create list items for each item in the list.
        SongAdapter adapter = new SongAdapter(this, songs);

        // Find the {@link ListView} object in the view hierarchy of the {@link Activity}.
        // There should be a {@link ListView} with the view ID called list, which is declared in the
        // word_list.xml layout file.
        ListView listView = findViewById(R.id.list);

        // Make the {@link ListView} use the {@link WordAdapter} we created above, so that the
        // {@link ListView} will display list items for each {@link Word} in the list.
        listView.setAdapter(adapter);
    }
}
