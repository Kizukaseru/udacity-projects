package com.android.musicplayer;

public class Playlist {

    private String mPlaylistItem;

    public Playlist(String playlistItem) {
        mPlaylistItem = playlistItem;

    }

    public String getPlaylistItem() {
        return mPlaylistItem;
    }


}