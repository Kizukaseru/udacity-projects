package com.android.musicplayer;

public class Song {

    private String mSongTrack;
    private String mSongArtist;
    private String mSongAlbum;

    public Song(String songTrack, String songArtist, String songAlbum) {
        mSongTrack = songTrack;
        mSongArtist = songArtist;
        mSongAlbum = songAlbum;
    }

    public String getSongTrack() {
        return mSongTrack;
    }

    public String getSongArtist() {
        return mSongArtist;
    }

    public String getSongAlbum() {
        return mSongAlbum;
    }


}