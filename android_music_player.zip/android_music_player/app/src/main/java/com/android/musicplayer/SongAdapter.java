package com.android.musicplayer;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class SongAdapter extends ArrayAdapter<Song> {

    public SongAdapter(Context context, ArrayList<Song> songs) {
        super(context, 0, songs);
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View listItemView = convertView;

        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.song_item, parent, false);
        }
        Song currentSong = getItem(position);

        TextView albumTrackTextView =listItemView.findViewById(R.id.albumTrack);
        albumTrackTextView.setText(currentSong.getSongTrack());

        TextView albumTitleTextView = listItemView.findViewById(R.id.albumTitle);
        albumTitleTextView.setText(currentSong.getSongAlbum());

        TextView albumArtistTextView = listItemView.findViewById(R.id.albumArtist);
        albumArtistTextView.setText(currentSong.getSongArtist());

        return listItemView;
    }


}
